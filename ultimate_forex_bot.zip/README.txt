ULTIMATE FOREX Signal Bot Setup Guide

1. Update app.py: Replace BOT_TOKEN and CHAT_ID with your actual bot token and Telegram group chat ID.
2. Upload all files to a GitHub repository.
3. Create a free account on https://render.com.
4. Connect your GitHub repository to Render.
5. Create a new Web Service on Render.
6. Set Build Command: pip install -r requirements.txt
7. Set Start Command: python3 app.py
8. Deploy the service.
9. Copy the deployed URL and add /webhook at the end.
10. Use this URL as the webhook URL in your TradingView alerts.

If you need help, just ask Arafat Rahman!
